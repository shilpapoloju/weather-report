﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Web.Script.Serialization;
using System.Xml.Serialization;
using System.IO;
using System.Xml;

namespace WeatherReport
{
    public partial class DispalyPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string appId = "216784f20b349cbcf5cfc3e21eaa6485";
            string url = string.Format("http://api.openweathermap.org/data/2.5/forecast/daily?q=Newark,US&mode=xml&units=metric&cnt=16&appid={0}", appId);

            try
            {
                using (WebClient client = new WebClient())
                {
                    string responseFromWS = client.DownloadString(url);

                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(responseFromWS);
                    string cityName = xmlDoc.SelectSingleNode("weatherdata/location/name").InnerText;
                    string countryName = xmlDoc.SelectSingleNode("weatherdata/location/country").InnerText;
                    lblLocation.Text = cityName + ", " + countryName;
                    lblSunRise.Text = xmlDoc.SelectSingleNode("weatherdata/sun").Attributes["rise"].Value;
                    lblSunSet.Text = xmlDoc.SelectSingleNode("weatherdata/sun").Attributes["set"].Value;
                    XmlNodeList timeNodes = xmlDoc.SelectNodes("weatherdata/forecast/time");

                    rptWeatherCtrl.DataSource = timeNodes;
                    rptWeatherCtrl.DataBind();
                }
            }
            catch (Exception)
            {
                Response.Redirect("Error.aspx");
            }
        }

       
       protected void rptWeatherCtrl_ItemDataBound(object source, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Label lblDay = e.Item.FindControl("lblDay") as Label;
                Panel divitem = e.Item.FindControl("divitem") as Panel;
                DateTime day;

                if(DateTime.TryParse(lblDay.Text, out day))
                {
                    if (day.Day % 3 == 0)
                    {
                        divitem.CssClass = "multiplesOfThree";
                    }
                    else if (day.Day % 5 == 0)
                    {
                        divitem.CssClass = "multiplesOfFive";
                    }
                    else if (day.Day % 3 == 0 && day.Day % 5 == 0)
                    {
                        divitem.CssClass = "multiplesOfThreeAndFive";
                    }
                    else if (isFibonacci(day.Day))
                    {
                        divitem.CssClass = "isFibonacci";
                    }
                    else
                    {
                        divitem.CssClass = "restAll";
                    }          
                }
            }
        }

        private bool isFibonacci(int dateInput)
        {
            if (isPerfectSquare(5 * dateInput * dateInput + 4) || isPerfectSquare(5 * dateInput * dateInput - 4)) 
            { return true; } 
            else { return false; }
        }

        private bool isPerfectSquare(int x)
        {
            int s = Convert.ToInt32(Math.Sqrt(x));
            return (s * s == x);
        }
    }
}